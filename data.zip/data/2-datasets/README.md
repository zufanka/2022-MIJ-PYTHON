# Horizon 2020
Horizon 2020 was the EU's research and innovation funding programme from 2014-2020 with a budget of nearly €80 billion. There are 2 datasets : organizations and project details. Be careful: there can be multiple organizations involved in the same project.

* [Data Source](https://data.europa.eu/data/datasets/cordish2020projects?locale=en)
* [More info](https://wayback.archive-it.org/12090/20220124075100/https:/ec.europa.eu/programmes/horizon2020/)

# European countries
* contains information on the population of European countries

# Horizon_Europe
Contains a colleciton of EU' research and innovation funding programme from 2020 on.